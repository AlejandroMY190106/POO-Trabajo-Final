package tottus;

public interface AccionesEmpleados {

    public void MostrarAcciones();

    public void AgregarCompra();

    public void EliminarCompra();
}
